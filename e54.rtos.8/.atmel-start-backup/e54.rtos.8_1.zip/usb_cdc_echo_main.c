#include <atmel_start.h>
#include <ff.h>
#include "rtos_start.h"
#include "atmel_start.h"
#include "mpu_wrappers.h"

#include <stdlib.h>
#define TASK_EXAMPLE_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_EXAMPLE_STACK_PRIORITY (tskIDLE_PRIORITY + 1)

#define len(p) confs[p].len
#define times(p) confs[p].times
#define overtime(p) confs[p].overtime
#define undertime(p) confs[p].undertime
uint8_t exa[5]= {0x2a,0x2b,0x2c,0x2d,0x2e};
#define max_len 64 //len of the time array
static uint8_t ans[512];


static uint8_t rec[512];
static uint16_t rec_index;



//static Queue_t *const xsem;
static TaskHandle_t      xRoutineTask0;
static TaskHandle_t      xRoutineTask1;

FATFS FatFs;		/* FatFs work area needed for each volume */
FIL Fil;			/* File object needed for each open file */


typedef struct conf_t{
	char name[16];
	uint32_t overtime;
	uint32_t undertime;
	uint32_t times[max_len];
	uint32_t len;
}conf;

conf confs[8];

typedef struct gunconf_t{
	
	uint8_t index_gun;
	//over PIN
	//normal PIN
	//PWM???
	
	uint8_t active;
	uint8_t starter;
} gunconf;

static gunconf gunconfs[2];
/*
index 0
over PB05
pwm PB09 PWM 0

index 1
over PB04
pwm PB15 PWM1

*/
void static open_over(uint8_t index){
	if (index){
		gpio_set_pin_level(PB04,1);
	}
	else{
		gpio_set_pin_level(PB05,1);
	}
}
void static open_normal(uint8_t index) {
	if (index){
		gpio_set_pin_level(PB15,1);
	}
	else{
		gpio_set_pin_level(PB09,1);
	}
}

void static open_under(uint8_t index) {
	if (index){
		PWM_1_init();
		pwm_set_parameters(&PWM_1,  1000,  500);
		pwm_enable(&PWM_1);
	}
	else{
		PWM_0_init();
		pwm_set_parameters(&PWM_0,  1000,  500);
		pwm_enable(&PWM_0);
	}
}

void static close_over(uint8_t index){
	if (index){
		gpio_set_pin_level(PB04,0);
	}
	else{
		gpio_set_pin_level(PB05,0);
	}
}


void static close_normal(uint8_t index){
	if (index){
		gpio_set_pin_level(PB15,0);
		
	}
	else{
		gpio_set_pin_level(PB09,0);
	}
}

void static close_under(uint8_t index){
	if (index){
		pwm_disable(&PWM_1);
		gpio_set_pin_direction(PB15, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(PB15, GPIO_PIN_FUNCTION_OFF);
		gpio_set_pin_level(PB15,0);
		}else{
		pwm_disable(&PWM_0);
		gpio_set_pin_direction(PB09, GPIO_DIRECTION_OUT);
		gpio_set_pin_function(PB09, GPIO_PIN_FUNCTION_OFF);
		gpio_set_pin_level(PB09,0);
	}
}


void preparesd(){
	uint8_t k;
	for (k=0;k<8;k++){
		confs[k].name[0]='c';
		confs[k].name[1]=48+k;
		confs[k].overtime=50;
		confs[k].undertime=3000;
		confs[k].times[0]=(k+1)*1000;
		confs[k].times[1]=1000;
		confs[k].times[2]=1000;
		confs[k].times[3]=1000;
		confs[k].times[4]=1000;
		confs[k].times[5]=1000;
		confs[k].len=5;
	}
	/*
	UINT bw;
	uint32_t buff[ sizeof(conf)/4];
	f_mount(&FatFs, "", 0);
	if (f_open(&Fil, "config.txt",  FA_WRITE) == FR_OK) {
	
	buff[0]=0;
	f_write(&Fil,buff, 1, &bw);
	int i,j;
	for(i=0;i<8;i++){
	
	uint32_t* copier = &confs[i];
	for (j=0;j<sizeof(conf)/4;j++){
	buff[j]=copier[j];
	}
	f_write(&Fil,buff, sizeof(conf)/4, &bw);
	}
	f_close(&Fil);
	}else{
	while(1);
	}
	*/
	
}

void load_times(){
	//carefully, this shit accept conf only with size multiple of 4B
	UINT bw;
	uint32_t buff[ sizeof(conf)/4];
	f_mount(&FatFs, "", 0);
	if (f_open(&Fil, "config.txt", FA_READ | FA_OPEN_EXISTING) == FR_OK) {
		f_read(&Fil,buff, 1, &bw);
		//active0=buff[0];
		int i,j;
		for(i=0;i<8;i++){
			f_read(&Fil,buff, sizeof(conf)/4, &bw);
			uint32_t* copier = &confs[i];
			for (j=0;j<sizeof(conf)/4;j++){
				copier[j]=buff[j];
			}
		}
		f_close(&Fil);
		}else{
		while(1);
	}
}

static void controller_routine(gunconf *gc)
{
	
	//WAIT UNTIL!!!!!!!!!!!!!!
	
	//uint8_t conf_set=gc->active;//  ((uint8_t)x) & 0x07;
	uint8_t index=gc->index_gun;// ((uint8_t)x>>4) & 0x01;
	while(1){
		/*
		wait for pressure, requires interrupt
		*/
		vTaskSuspend(NULL);
		uint32_t time_left = 0;
		uint8_t i=0;
		while (i<len(gc->active)){
			time_left=times(gc->active)[i];
			if (overtime(gc->active)>0){
				open_over(index);
				if (overtime(gc->active) < time_left){
					os_sleep(overtime(gc->active));
					time_left= time_left-overtime(gc->active);
				}
				else{
					os_sleep(time_left);
					time_left = 0;
				}
				close_over(index);
			}
			
			if (time_left > 0){
				open_normal(index);
				if ((undertime(gc->active)<0xFFFFFFFF)&& (time_left > undertime(gc->active))){
					os_sleep(undertime(gc->active));
					close_normal(index);
					open_under(index);
					os_sleep(time_left- undertime(gc->active));
					close_under(index);
				}
				
				else{
					os_sleep(time_left);
					close_normal(index);
				}
			}
			i++;
			if (i<len(gc->active)){
				os_sleep(times(gc->active)[i]);
				i++;
			}
		}
	}
}

static void SPI_buffering(const struct spi_s_async_descriptor *const desc)
{
	struct io_descriptor *io;
	spi_s_async_get_io_descriptor(&SPI_0, &io);
	io_read(io, &rec[rec_index++], 1);
	
}

static void complete_cb_SPI_0(const struct spi_s_async_descriptor *const desc)
{
	
	struct io_descriptor *io;
	spi_s_async_get_io_descriptor(&SPI_0, &io);
	uint8_t x,y,z;
	x=y=z=0;
	x=rec[0];
	y=rec[1];

	
	if(x==1){
		//read active
		ans[0]=0xFF;
		ans[1]=gunconfs[y].active;
		io_write(io, ans, 2);
	}
	else if(x==3){
		//edit active
		gunconfs[y].active=rec[2];
	}
	else if (x==2)	{
		//read conf
		int j;
		ans[0]=0xFF;
		uint8_t* copier = &confs[y];
		for (j=0;j<sizeof(conf);j++){
			ans[j+1]=copier[j];
		}
		io_write(io, ans, j+1);
	}
	else if (x==4)	{
		//edit conf
		int j;
		uint8_t* copier = &confs[y];
		for (j=0;j<sizeof(conf);j++){
			copier[j]=rec[j+2];
		}
	}
	rec_index=0;
}

void SPI_0_example(void)
{
	spi_s_async_register_callback(&SPI_0, SPI_S_CB_COMPLETE, (FUNC_PTR)complete_cb_SPI_0);
	spi_s_async_register_callback(&SPI_0, SPI_S_CB_RX, (FUNC_PTR)SPI_buffering);
	spi_s_async_enable(&SPI_0);
	rec_index=0;
}


static void button_on_PA16_pressed(void)
{
	gpio_toggle_pin_level(LED0);
	xTaskResumeFromISR(xRoutineTask0);
	xTaskResumeFromISR(xRoutineTask1);
	portYIELD_FROM_ISR( pdTRUE);
}


int main(void)
{
	atmel_start_init();
	//cdcd_acm_example();
	preparesd();
	//load_times();
	
	close_under(0);
	close_under(1);
	
	gunconfs[0].index_gun=0;
	gunconfs[0].active=0;
	gunconfs[1].index_gun=1;
	gunconfs[1].active=0;
	
	ext_irq_register(PIN_PA16, button_on_PA16_pressed);
	NVIC_SetPriority(EIC_0_IRQn, 5 );
	SPI_0_example();


	if (xTaskCreate(controller_routine, "C0", TASK_EXAMPLE_STACK_SIZE,(void*)&gunconfs[0],
	TASK_EXAMPLE_STACK_PRIORITY, &xRoutineTask0)!= pdPASS) {
		while (1) {
			;
		}
	}
	
	if (xTaskCreate(controller_routine, "C1", TASK_EXAMPLE_STACK_SIZE,(void*)&gunconfs[1],
	TASK_EXAMPLE_STACK_PRIORITY, &xRoutineTask1)!= pdPASS) {
		while (1) {
			;
		}
	}

	vTaskStartScheduler();
	
	while (1) {
	}
}

